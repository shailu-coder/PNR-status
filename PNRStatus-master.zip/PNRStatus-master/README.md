# PNRStatus

An Android application which shows PNR status of Indian railways using railway api.

What is PNR?
PNR(Passenger Name Record) is unique number given to booking done for a travel via Indian Railways.

Use of this project:
This project will help in getting started with android application development. Railways api is used in order to fetch 
PNR number status. You may need to register with https://railwayapi.com to get the api key as I have not included it. 
You may have to replace your key in PNRStatusHome.java so that when you build application and port it on Android you can use it.
